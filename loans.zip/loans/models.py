# loans/models.py
"""
Simplified Loan Models.
Just 2 models: Loan and Payment.
Loan lifecycle: pending → approved → contract_sent → contract_signed → funded → active → paid_off (or defaulted)
"""
from django.db import models
from django.utils import timezone
from accounts.models import Customer
from banking.models import BankAccount
import uuid


class Loan(models.Model):
    """
    Main loan entity - handles entire loan lifecycle.
    """
    # Loan Types
    TYPE_CHOICES = [
        ('nojuice', 'NoJuice'),
        ('payday', 'Payday'),
    ]
    
    # Loan Status - Linear lifecycle
    STATUS_CHOICES = [
        ('pending', 'Pending Review'),        # New application
        ('approved', 'Approved'),             # Approved by agent
        ('declined', 'Declined'),             # Declined by agent
        ('contract_sent', 'Contract Sent'),   # Contract emailed
        ('contract_signed', 'Contract Signed'), # Customer signed
        ('funded', 'Funded'),                 # Money sent to customer
        ('active', 'Active'),                 # Loan is being repaid
        ('paid_off', 'Paid Off'),             # Fully repaid
        ('defaulted', 'Defaulted'),           # Customer defaulted
    ]
    
    # Funding Methods
    FUNDING_METHOD_CHOICES = [
        ('etransfer', 'Interac e-Transfer'),
        ('eft', 'EFT / Direct Deposit'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='loans')
    
    # Loan Details
    type = models.CharField(max_length=20, choices=TYPE_CHOICES, default='nojuice')
    principal = models.DecimalField(max_digits=10, decimal_places=2, help_text="Amount borrowed")
    fee = models.DecimalField(max_digits=10, decimal_places=2, default=0, help_text="Total fee charged")
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, help_text="Principal + Fee")
    balance = models.DecimalField(max_digits=10, decimal_places=2, help_text="Remaining balance")
    
    # Status
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    
    # Banking (for funding and collections)
    bank_account = models.ForeignKey(
        BankAccount, 
        on_delete=models.SET_NULL, 
        null=True, blank=True,
        related_name='loans',
        help_text="Account used for funding and PAD collections"
    )
    
    # Funding Details
    funding_method = models.CharField(max_length=20, choices=FUNDING_METHOD_CHOICES, blank=True, null=True)
    funding_reference = models.CharField(max_length=100, blank=True, null=True)
    funded_at = models.DateTimeField(null=True, blank=True)
    
    # Contract Details
    contract_id = models.CharField(max_length=100, blank=True, null=True, help_text="DocuSign envelope ID")
    contract_sent_at = models.DateTimeField(null=True, blank=True)
    contract_signed_at = models.DateTimeField(null=True, blank=True)
    
    # Approval/Decline
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(
        'accounts.User', on_delete=models.SET_NULL, 
        null=True, blank=True, related_name='approved_loans'
    )
    declined_at = models.DateTimeField(null=True, blank=True)
    decline_reason = models.TextField(blank=True, null=True)
    
    # Notes
    notes = models.TextField(blank=True, null=True, help_text="Internal notes")
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'loans_loan'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Loan #{str(self.id)[:8]} - {self.customer} - ${self.principal}"
    
    def save(self, *args, **kwargs):
        # Auto-calculate total_amount if not set
        if not self.total_amount:
            self.total_amount = self.principal + self.fee
        # Initialize balance to total_amount for new loans
        if not self.balance:
            self.balance = self.total_amount
        super().save(*args, **kwargs)
    
    # ----- Actions -----
    
    def approve(self, user):
        """Approve the loan."""
        self.status = 'approved'
        self.approved_at = timezone.now()
        self.approved_by = user
        self.save()
    
    def decline(self, reason):
        """Decline the loan."""
        self.status = 'declined'
        self.declined_at = timezone.now()
        self.decline_reason = reason
        self.save()
    
    def mark_contract_sent(self, contract_id):
        """Mark contract as sent."""
        self.status = 'contract_sent'
        self.contract_id = contract_id
        self.contract_sent_at = timezone.now()
        self.save()
    
    def mark_contract_signed(self):
        """Mark contract as signed."""
        self.status = 'contract_signed'
        self.contract_signed_at = timezone.now()
        self.save()
    
    def fund(self, method, reference):
        """Mark loan as funded."""
        self.status = 'funded'
        self.funding_method = method
        self.funding_reference = reference
        self.funded_at = timezone.now()
        self.save()
        # Auto-transition to active after funding
        self.status = 'active'
        self.save()
    
    def apply_payment(self, amount):
        """Apply a payment to the loan balance."""
        self.balance = max(0, self.balance - amount)
        if self.balance == 0:
            self.status = 'paid_off'
        self.save()
    
    def mark_defaulted(self):
        """Mark loan as defaulted."""
        self.status = 'defaulted'
        self.save()


class Payment(models.Model):
    """
    Single payment record - both scheduled (PAD) and actual payments.
    """
    # Payment Types
    TYPE_CHOICES = [
        ('scheduled', 'Scheduled PAD'),       # Pre-authorized debit
        ('manual', 'Manual Payment'),          # Agent-recorded payment
        ('etransfer', 'e-Transfer Received'),  # Customer sent e-transfer
    ]
    
    # Payment Status
    STATUS_CHOICES = [
        ('scheduled', 'Scheduled'),    # Future payment
        ('pending', 'Pending'),        # Processing
        ('completed', 'Completed'),    # Successfully collected
        ('failed', 'Failed'),          # Failed to collect
        ('nsf', 'NSF'),                # Non-sufficient funds
        ('cancelled', 'Cancelled'),    # Cancelled by agent
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    loan = models.ForeignKey(Loan, on_delete=models.CASCADE, related_name='payments')
    
    # Payment Details
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    type = models.CharField(max_length=20, choices=TYPE_CHOICES, default='scheduled')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='scheduled')
    scheduled_date = models.DateField(help_text="Date payment is scheduled for")
    
    # Processing
    processed_at = models.DateTimeField(null=True, blank=True)
    failure_reason = models.TextField(blank=True, null=True)
    reference = models.CharField(max_length=100, blank=True, null=True)
    
    # Notes
    notes = models.TextField(blank=True, null=True)
    
    # Audit
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        'accounts.User', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='created_payments'
    )
    
    class Meta:
        db_table = 'loans_payment'
        ordering = ['scheduled_date', '-created_at']
    
    def __str__(self):
        return f"Payment ${self.amount} for Loan #{str(self.loan_id)[:8]} on {self.scheduled_date}"
    
    def complete(self):
        """Mark payment as completed and apply to loan."""
        self.status = 'completed'
        self.processed_at = timezone.now()
        self.save()
        # Apply payment to loan balance
        self.loan.apply_payment(self.amount)
    
    def fail(self, reason=''):
        """Mark payment as failed."""
        self.status = 'failed'
        self.failure_reason = reason
        self.processed_at = timezone.now()
        self.save()
    
    def mark_nsf(self):
        """Mark payment as NSF."""
        self.status = 'nsf'
        self.failure_reason = 'Non-sufficient funds'
        self.processed_at = timezone.now()
        self.save()
    
    def cancel(self):
        """Cancel the payment."""
        self.status = 'cancelled'
        self.save()
