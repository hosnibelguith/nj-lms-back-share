# loans/views.py
"""
Simplified Loan Views - Only Loan and Payment.
"""
from rest_framework import viewsets, status, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from django.utils import timezone
from django.db.models import Q, Sum
from .models import Loan, Payment
from .serializers import (
    LoanSerializer, LoanListSerializer, LoanCreateSerializer,
    LoanApproveSerializer, LoanDeclineSerializer, LoanFundSerializer,
    PaymentSerializer, PaymentCreateSerializer, RecordPaymentSerializer
)


class LoanViewSet(viewsets.ModelViewSet):
    """
    Loan CRUD + Actions.
    
    Actions:
    - approve: Approve a pending loan
    - decline: Decline a pending loan
    - send_contract: Send contract to customer
    - fund: Mark loan as funded
    - record_payment: Record a manual payment
    - mark_defaulted: Mark loan as defaulted
    """
    queryset = Loan.objects.select_related('customer', 'bank_account', 'approved_by').prefetch_related('payments')
    permission_classes = [permissions.IsAuthenticated]
    
    def get_serializer_class(self):
        if self.action == 'list':
            return LoanListSerializer
        if self.action == 'create':
            return LoanCreateSerializer
        return LoanSerializer
    
    def get_queryset(self):
        qs = super().get_queryset()
        
        # Filter by status
        status_param = self.request.query_params.get('status')
        if status_param:
            qs = qs.filter(status=status_param)
        
        # Filter by customer
        customer_id = self.request.query_params.get('customer_id')
        if customer_id:
            qs = qs.filter(customer_id=customer_id)
        
        # Filter by type
        loan_type = self.request.query_params.get('type')
        if loan_type:
            qs = qs.filter(type=loan_type)
        
        # Search
        search = self.request.query_params.get('search')
        if search:
            qs = qs.filter(
                Q(customer__first_name__icontains=search) |
                Q(customer__last_name__icontains=search) |
                Q(customer__email__icontains=search)
            )
        
        return qs
    
    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        """Approve a pending loan."""
        loan = self.get_object()
        
        if loan.status != 'pending':
            return Response(
                {'error': 'Only pending loans can be approved'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        serializer = LoanApproveSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        # Update bank account if provided
        bank_account_id = serializer.validated_data.get('bank_account_id')
        if bank_account_id:
            loan.bank_account_id = bank_account_id
        
        loan.approve(user=request.user)
        
        return Response(LoanSerializer(loan).data)
    
    @action(detail=True, methods=['post'])
    def decline(self, request, pk=None):
        """Decline a pending loan."""
        loan = self.get_object()
        
        if loan.status != 'pending':
            return Response(
                {'error': 'Only pending loans can be declined'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        serializer = LoanDeclineSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        loan.decline(reason=serializer.validated_data['reason'])
        
        return Response(LoanSerializer(loan).data)
    
    @action(detail=True, methods=['post'])
    def send_contract(self, request, pk=None):
        """Send contract to customer (triggers DocuSign)."""
        loan = self.get_object()
        
        if loan.status != 'approved':
            return Response(
                {'error': 'Only approved loans can have contracts sent'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # TODO: Integrate with DocuSign - for now placeholder
        from .tasks import send_contract_task
        send_contract_task.delay(str(loan.id))
        
        return Response({'message': 'Contract send initiated', 'loan_id': str(loan.id)})
    
    @action(detail=True, methods=['post'])
    def fund(self, request, pk=None):
        """Fund the loan (mark as funded after sending money)."""
        loan = self.get_object()
        
        if loan.status != 'contract_signed':
            return Response(
                {'error': 'Only signed contracts can be funded'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        serializer = LoanFundSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        loan.fund(
            method=serializer.validated_data['method'],
            reference=serializer.validated_data['reference']
        )
        
        return Response(LoanSerializer(loan).data)
    
    @action(detail=True, methods=['post'])
    def record_payment(self, request, pk=None):
        """Record a manual payment."""
        loan = self.get_object()
        
        if loan.status not in ['active', 'funded']:
            return Response(
                {'error': 'Can only record payments on active loans'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        serializer = RecordPaymentSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        # Create payment record
        payment = Payment.objects.create(
            loan=loan,
            amount=serializer.validated_data['amount'],
            type=serializer.validated_data['type'],
            scheduled_date=timezone.now().date(),
            reference=serializer.validated_data.get('reference', ''),
            notes=serializer.validated_data.get('notes', ''),
            created_by=request.user
        )
        
        # Mark as completed (applies to loan balance)
        payment.complete()
        
        return Response(LoanSerializer(loan).data)
    
    @action(detail=True, methods=['post'])
    def mark_defaulted(self, request, pk=None):
        """Mark loan as defaulted."""
        loan = self.get_object()
        
        if loan.status not in ['active', 'funded']:
            return Response(
                {'error': 'Only active loans can be defaulted'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        loan.mark_defaulted()
        
        return Response(LoanSerializer(loan).data)
    
    @action(detail=False, methods=['get'])
    def stats(self, request):
        """Dashboard statistics."""
        qs = self.get_queryset()
        
        return Response({
            'total_funded': qs.filter(status__in=['funded', 'active', 'paid_off']).aggregate(
                total=Sum('principal')
            )['total'] or 0,
            'total_balance': qs.filter(status='active').aggregate(
                total=Sum('balance')
            )['total'] or 0,
            'pending': qs.filter(status='pending').count(),
            'approved': qs.filter(status='approved').count(),
            'active': qs.filter(status='active').count(),
            'defaulted': qs.filter(status='defaulted').count(),
        })


class PaymentViewSet(viewsets.ModelViewSet):
    """Payment CRUD + Actions."""
    queryset = Payment.objects.select_related('loan', 'loan__customer', 'created_by')
    serializer_class = PaymentSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_serializer_class(self):
        if self.action == 'create':
            return PaymentCreateSerializer
        return PaymentSerializer
    
    def get_queryset(self):
        qs = super().get_queryset()
        
        loan_id = self.request.query_params.get('loan_id')
        if loan_id:
            qs = qs.filter(loan_id=loan_id)
        
        status_param = self.request.query_params.get('status')
        if status_param:
            qs = qs.filter(status=status_param)
        
        return qs
    
    @action(detail=True, methods=['post'])
    def complete(self, request, pk=None):
        """Mark payment as completed."""
        payment = self.get_object()
        if payment.status not in ['scheduled', 'pending']:
            return Response({'error': 'Payment cannot be completed'}, status=status.HTTP_400_BAD_REQUEST)
        payment.complete()
        return Response(PaymentSerializer(payment).data)
    
    @action(detail=True, methods=['post'])
    def fail(self, request, pk=None):
        """Mark payment as failed."""
        payment = self.get_object()
        reason = request.data.get('reason', '')
        payment.fail(reason)
        return Response(PaymentSerializer(payment).data)
    
    @action(detail=True, methods=['post'])
    def nsf(self, request, pk=None):
        """Mark payment as NSF."""
        payment = self.get_object()
        payment.mark_nsf()
        return Response(PaymentSerializer(payment).data)
    
    @action(detail=True, methods=['post'])
    def cancel(self, request, pk=None):
        """Cancel payment."""
        payment = self.get_object()
        if payment.status not in ['scheduled', 'pending']:
            return Response({'error': 'Only scheduled payments can be cancelled'}, status=status.HTTP_400_BAD_REQUEST)
        payment.cancel()
        return Response(PaymentSerializer(payment).data)
