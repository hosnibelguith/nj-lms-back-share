# loans/serializers.py
"""
Simplified Loan Serializers.
"""
from rest_framework import serializers
from .models import Loan, Payment
from accounts.serializers import CustomerSerializer
from banking.serializers import BankAccountSerializer


class PaymentSerializer(serializers.ModelSerializer):
    """Payment serializer."""
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    type_display = serializers.CharField(source='get_type_display', read_only=True)
    
    class Meta:
        model = Payment
        fields = [
            'id', 'loan', 'amount', 'type', 'type_display',
            'status', 'status_display', 'scheduled_date',
            'processed_at', 'failure_reason', 'reference', 'notes',
            'created_at', 'created_by'
        ]
        read_only_fields = ['id', 'created_at', 'processed_at']


class PaymentCreateSerializer(serializers.ModelSerializer):
    """Create payment."""
    class Meta:
        model = Payment
        fields = ['loan', 'amount', 'type', 'scheduled_date', 'notes']


class LoanSerializer(serializers.ModelSerializer):
    """Full loan serializer with nested data."""
    customer = CustomerSerializer(read_only=True)
    customer_id = serializers.UUIDField(write_only=True, source='customer.id', required=False)
    bank_account = BankAccountSerializer(read_only=True)
    payments = PaymentSerializer(many=True, read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    type_display = serializers.CharField(source='get_type_display', read_only=True)
    
    class Meta:
        model = Loan
        fields = [
            'id', 'customer', 'customer_id',
            'type', 'type_display', 'principal', 'fee', 'total_amount', 'balance',
            'status', 'status_display',
            'bank_account',
            'funding_method', 'funding_reference', 'funded_at',
            'contract_id', 'contract_sent_at', 'contract_signed_at',
            'approved_at', 'approved_by', 'declined_at', 'decline_reason',
            'notes', 'payments',
            'created_at', 'updated_at'
        ]
        read_only_fields = [
            'id', 'total_amount', 'balance', 'funded_at',
            'contract_sent_at', 'contract_signed_at',
            'approved_at', 'approved_by', 'declined_at',
            'created_at', 'updated_at'
        ]


class LoanListSerializer(serializers.ModelSerializer):
    """Lightweight serializer for loan lists."""
    customer_name = serializers.SerializerMethodField()
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    next_payment = serializers.SerializerMethodField()
    
    class Meta:
        model = Loan
        fields = [
            'id', 'customer_id', 'customer_name',
            'type', 'principal', 'total_amount', 'balance',
            'status', 'status_display', 'next_payment',
            'created_at'
        ]
    
    def get_customer_name(self, obj):
        return obj.customer.full_name
    
    def get_next_payment(self, obj):
        payment = obj.payments.filter(status='scheduled').order_by('scheduled_date').first()
        if payment:
            return {'date': payment.scheduled_date, 'amount': payment.amount}
        return None


class LoanCreateSerializer(serializers.ModelSerializer):
    """Create loan."""
    class Meta:
        model = Loan
        fields = ['customer', 'type', 'principal', 'fee', 'bank_account', 'notes']
    
    def create(self, validated_data):
        principal = validated_data.get('principal', 0)
        fee = validated_data.get('fee', 0)
        validated_data['total_amount'] = principal + fee
        validated_data['balance'] = principal + fee
        return super().create(validated_data)


# ----- Action Serializers -----

class LoanApproveSerializer(serializers.Serializer):
    """Approve loan."""
    bank_account_id = serializers.UUIDField(required=False)


class LoanDeclineSerializer(serializers.Serializer):
    """Decline loan."""
    reason = serializers.CharField(required=True)


class LoanFundSerializer(serializers.Serializer):
    """Fund loan."""
    method = serializers.ChoiceField(choices=['etransfer', 'eft'])
    reference = serializers.CharField(required=True, max_length=100)


class RecordPaymentSerializer(serializers.Serializer):
    """Record manual payment."""
    amount = serializers.DecimalField(max_digits=10, decimal_places=2)
    type = serializers.ChoiceField(choices=['manual', 'etransfer'], default='manual')
    reference = serializers.CharField(required=False, max_length=100, allow_blank=True)
    notes = serializers.CharField(required=False, allow_blank=True)
