# loans/services.py
"""
Business logic services for loan operations.
Called by views and celery tasks.
"""
from decimal import Decimal
from datetime import timedelta
from django.db import transaction
from django.utils import timezone
from .models import Loan, Payment


class LoanService:
    """Service class for loan operations."""
    
    @staticmethod
    @transaction.atomic
    def approve_loan(loan: Loan, approved_by, notes: str = None) -> Loan:
        """Approve a loan application."""
        if loan.status != 'pending':
            raise ValueError(f"Cannot approve loan in status: {loan.status}")
        
        loan.approve(approved_by)
        if notes:
            loan.notes = notes
            loan.save()
        
        return loan
    
    @staticmethod
    @transaction.atomic
    def decline_loan(loan: Loan, reason: str) -> Loan:
        """Decline a loan application."""
        if loan.status != 'pending':
            raise ValueError(f"Cannot decline loan in status: {loan.status}")
        
        loan.decline(reason)
        return loan
    
    @staticmethod
    @transaction.atomic
    def fund_loan(loan: Loan, method: str = 'eft') -> Loan:
        """Fund an approved loan."""
        if loan.status != 'contract_signed':
            raise ValueError(f"Cannot fund loan in status: {loan.status}")
        
        # Generate reference number
        ref = f"{method.upper()}-{timezone.now().strftime('%Y%m%d')}-{str(loan.id)[:8].upper()}"
        loan.fund(method, ref)
        return loan
    
    @staticmethod
    @transaction.atomic
    def record_payment(loan: Loan, amount: Decimal, payment_type: str = 'manual') -> Payment:
        """Record a payment on a loan."""
        payment = Payment.objects.create(
            loan=loan,
            amount=amount,
            type=payment_type,
            status='completed',
            scheduled_date=timezone.now().date(),
            processed_at=timezone.now()
        )
        
        # Apply payment to loan balance
        loan.apply_payment(amount)
        return payment
    
    @staticmethod
    @transaction.atomic
    def generate_payment_schedule(loan: Loan, num_payments: int, 
                                  payment_amount: Decimal, 
                                  start_date,
                                  frequency_days: int = 14) -> list:
        """Generate a payment schedule for a loan."""
        payments = []
        current_date = start_date
        remaining = loan.total_amount
        
        for i in range(num_payments):
            is_last = (i == num_payments - 1)
            amt = remaining if is_last else min(payment_amount, remaining)
            remaining -= amt
            
            payment = Payment.objects.create(
                loan=loan,
                amount=amt,
                scheduled_date=current_date,
                type='scheduled',
                status='scheduled'
            )
            payments.append(payment)
            current_date += timedelta(days=frequency_days)
        
        return payments
