# loans/apps.py
from django.apps import AppConfig


class LoansConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'loans'
    verbose_name = 'Loans & Payments'

    def ready(self):
        import loans.signals  # noqa
